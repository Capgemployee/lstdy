﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaceImplementation
{
    class Program
    {
        static void Main(string[] args)
        {
            IMyInterface1 m1 = new Employee();
            m1.Show();
            m1.Display();

            IMyInterface2 m2 = new Employee();
            m2.Show();
            m2.Print();

            //Employee emp = new Employee();
            //emp.Show();
            //emp.Print();
            //emp.Display();
        }
    }
}
