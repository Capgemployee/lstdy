﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ParameterTypeDemo
{
    class Program
    {
        public void SwapByValue(int num1, int num2)
        {
            int temp = num1;
            num1 = num2;
            num2 = temp;
        }

        public void SwapByReference(ref int num1, ref int num2)
        {
            int temp = num1;
            num1 = num2;
            num2 = temp;
        }

        public void CircleFunction(int radius, out double area, out double volume)
        {
            area = 3.14 * radius * radius;
            volume = 4 / 3 * 3.14 * radius * radius * radius;
        }

        public string Concat(params string[] str)
        {
            string result = "";
            for (int i = 0; i < str.Length; i++)
            {
                result = result + str[i];
            }

            return result;
        }

        static void Main(string[] args)
        {
            int num1, num2;
            Program p = new Program();
            
            Console.Write("Enter Number 1 : ");
            num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Number 2 : ");
            num2 = Convert.ToInt32(Console.ReadLine());

            Console.WriteLine("\n********************Output of Swap Method Pass By Value***************");
            Console.WriteLine("Before Swapping Numbers : ");
            Console.WriteLine("\tNumber 1 : " + num1);
            Console.WriteLine("\tNumber 2 : " + num2);

            p.SwapByValue(num1, num2);

            Console.WriteLine("After Swapping Numbers : ");
            Console.WriteLine("\tNumber 1 : " + num1);
            Console.WriteLine("\tNumber 2 : " + num2);

            Console.WriteLine("\n********************Output of Swap Method Pass By Reference***************");
            Console.WriteLine("Before Swapping Numbers : ");
            Console.WriteLine("\tNumber 1 : " + num1);
            Console.WriteLine("\tNumber 2 : " + num2);
            
            p.SwapByReference(ref num1, ref num2);

            Console.WriteLine("After Swapping Numbers : ");
            Console.WriteLine("\tNumber 1 : " + num1);
            Console.WriteLine("\tNumber 2 : " + num2);


            Console.WriteLine("\n********************Output of Circle Method Pass By Out***************");
            int radius;
            double area, volume;

            Console.Write("Enter Radius : ");
            radius = Convert.ToInt32(Console.ReadLine());

            p.CircleFunction(radius, out area, out volume);

            Console.WriteLine("Area of Circle is : " + area);
            Console.WriteLine("Volume of Circle is : " + volume);

            Console.WriteLine("\n********************Output of Concat Method Pass By params***************");
            Console.WriteLine(p.Concat(".NET", "Batch"));
            Console.WriteLine(p.Concat(".NET", "Framework", "with", "C#"));
            
            Console.ReadKey();
        }
    }
}
