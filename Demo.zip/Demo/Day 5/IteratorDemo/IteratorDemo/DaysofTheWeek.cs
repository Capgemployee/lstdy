﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace IteratorDemo
{
    public class DaysofTheWeek : IEnumerable
    {
        string[] days = { "Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };

        IEnumerator IEnumerable.GetEnumerator()
        {
            for (int i = 0; i < days.Length; i++)
            {
                yield return days[i];   
            }
        }
    }
}
