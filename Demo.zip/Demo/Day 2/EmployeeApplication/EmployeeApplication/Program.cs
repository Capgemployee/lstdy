﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeApplication
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee[] emp = new Employee[5];

            for (int i = 0; i < emp.Length; i++)
            {
                emp[i] = new Employee();

                Console.Write("Enter Employee ID : ");
                emp[i].EmployeeID = Convert.ToInt32(Console.ReadLine());

                Console.Write("Enter Employee Name : ");
                emp[i].EmployeeName = Console.ReadLine();

                Console.Write("Enter Employee Salary : ");
                emp[i].Salary = Convert.ToDouble(Console.ReadLine());
            }

            for (int i = 0; i < emp.Length; i++)
            {
                Console.WriteLine("\n\nEmployee ID is : " + emp[i].EmployeeID);
                Console.WriteLine("Employee Name is : " + emp[i].EmployeeName);
                Console.WriteLine("Employee Salary is : " + emp[i].Salary);
            }
            

            Console.ReadKey();
        }
    }
}
