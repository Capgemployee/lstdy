using System;

public class Hello
{
	public static void Main()
	{
		Console.WriteLine("Hello .NET Batch");
	}
}