﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EMS.Entity
{
    public enum Relationship
    {
        Father=1,
        Mother=2
    }
}
