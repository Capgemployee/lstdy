﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileDownloaderUtility
{
    public delegate void DownloadCompeteHandler(int perc);
    public class FileDownloader
    {
        public string resourceUrl;
        public string resourceSavePath;
        public event DownloadCompeteHandler DownLoadComplete;
        public FileDownloader(string url, string savepath)
        {
            this.resourceUrl = url;
            this.resourceSavePath = savepath;
        }
        public void DownLoadResource()
        {
            //This is just download simulation place holder code
           
            for (int i = 0; i < 4; i++)
            {
               
                //Dummy loop to add a delay
                for (int j = 0; j < 100; j++)
                {
                    Handler(j);
                    OnDownLoadComplete(j * 25);
                   
                }
                Console.WriteLine("\nFile is downloaded successfully");
                
            }
        }
        public void Handler(int j)
        {
            Console.WriteLine(j+"%");
            
        }

        public void OnDownLoadComplete(int j)
        {
            Console.WriteLine("\nFile is downloding");
            if (DownLoadComplete == null)
            {
                DownLoadComplete(j);
            }
            
           
        }
    }
}

