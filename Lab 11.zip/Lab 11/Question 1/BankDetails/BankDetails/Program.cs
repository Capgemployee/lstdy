﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankDetails
{
    public delegate void PaymentDelegate(double BalanceAmount,double CreditAmount);
    public class PaymentEventPublisher
    {
  
        public event PaymentDelegate MakePaymentEvent;
        public void InvokePaymentEvent(double BalanceAmount, double CreditAmount)
        {
            if (MakePaymentEvent !=null)
            {
                MakePaymentEvent(BalanceAmount,CreditAmount);
            }
            else
            {
                Console.WriteLine("\nAmount is not credited");
            }
        }
    }

    public class PaymentEventSubscriber
    { 
       public void PaymentMethod(double BalanceAmount, double CreditAmount)
        {
                Console.WriteLine("\nAmount is Credited Sucessfully");
        }
    }
   public class Program
    {
       
        static void Main(string[] args)
        {
            PaymentEventPublisher obj1 = new PaymentEventPublisher();
            PaymentEventSubscriber obj2 = new PaymentEventSubscriber();
            CreditCard obj3 = new CreditCard();
            Console.WriteLine("\n*****Credit Card Bill Payment Event using Delegate Concept of Event Model****\n");
            obj3.GetBalance("1275-2564-4785-56321","Mahesh Bhat",12000);
            obj3.GetCreditLimit();

            obj1.MakePaymentEvent += obj2.PaymentMethod;
            obj1.InvokePaymentEvent(12000,20000);
            Console.ReadKey(); 

        }
    }
}
