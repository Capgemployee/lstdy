﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BankDetails
{
    public class CreditCard
    {

        double CreditLimit = 50000;
        public void GetBalance(string CreditCardNo, string CardHolderName, double BalanceAmount)
        {
            Console.WriteLine("\nCreditCard Number:" + CreditCardNo);
            Console.WriteLine("\nCardHolder Name:" + CardHolderName);
            Console.WriteLine("\nBalance Amount:" + BalanceAmount);
        }

        public void GetCreditLimit()
        {
            Console.WriteLine("\nCredit Limit is:" + CreditLimit);
        }

        public void MakePayment(double BalanceAmount, double CreditAmount)
        {
            BalanceAmount = BalanceAmount + CreditAmount; 
        }
    }
}
