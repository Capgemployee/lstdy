﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GPB.Entity;
using GPB.Exception;
using GPB.BL;

namespace GPB.PL
{
    class GuestApplicationTest
    {
        //Adding the guest
        public static void AddGuest()
        {
            Guest guest = new Guest();

            try
            {
                Console.Write("Enter Guest ID : ");
                guest.GuestID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Guest Name : ");
                guest.GuestName = Console.ReadLine();
                Console.Write("Enter Relationship :\n 1.Father \n 2.Mother \n 3.Brother \n 4.Sister \n 5.Cousin \n 6.Uncle \n 7.Aunt \n 8.Son \n 9.Daughter \n 10.Friend \n");
                guest.Relationship = (Relation)Enum.Parse(typeof(Relation), Console.ReadLine());
                Console.Write("Enter Contact Number : ");
                guest.ContactNumber = Console.ReadLine();

                bool guestAdded = GuestBL.AddGuest(guest);

                if (guestAdded)
                {
                    Console.WriteLine("Employee Added Successfully");
                }
                else
                {
                    throw new GuestException("Guest not Added");
                }
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Display all Guest list
        public static void DisplayAllGuest()
        {
            try
            {
                List<Guest> guestList = GuestBL.DisplayAllGuest();

                if (guestList.Count > 0)
                {
                    Console.WriteLine("*********************************************************************");
                    Console.WriteLine("Guest ID     Guest Name      Relationship     Phone Number");
                    Console.WriteLine("*********************************************************************");
                    foreach (Guest guest in guestList)
                    {
                        Console.WriteLine(guest.GuestID + "\t" + guest.GuestName + "\t" + guest.Relationship + "\t" + guest.ContactNumber);
                    }
                    Console.WriteLine("***************************************************************************************");
                }
                else
                {
                    throw new GuestException("Guest List is Empty");
                }
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Search Guest By ID
        public static void DisplayAllGuestByID()
        {
            Guest guest = null;

            try
            {
                Console.Write("Enter Guest ID for Search : ");
                int guestID = Convert.ToInt32(Console.ReadLine());

                guest = GuestBL.DisplayAllGuestByID(guestID);

                if (guest != null)
                {
                    Console.WriteLine("Guest ID : " + guest.GuestID);
                    Console.WriteLine("Guest Name : " + guest.GuestName);
                    Console.WriteLine("Relationship : " + guest.Relationship);
                    Console.WriteLine("Contact Number : " + guest.ContactNumber);
                }
                else
                {
                    throw new GuestException("Guest Not found with ID " + guestID);
                }
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Search Guest By Relation
        public static void DisplayAllGuestByRelation()
        {
            List<Guest> guestList = null;

            try
            {
                Console.Write("Enter Guest Relationship for Search : ");
                Relation relationship = (Relation)Enum.Parse(typeof(Relation), Console.ReadLine());

                guestList = GuestBL.DisplayAllGuestByRelation(relationship);

                if (guestList != null)
                {
                    foreach (Guest guest in guestList)
                    {
                        Console.WriteLine("Guest ID : " + guest.GuestID);
                        Console.WriteLine("Guest Name : " + guest.GuestName);
                        Console.WriteLine("Relationship : " + guest.Relationship);
                        Console.WriteLine("Contact Number : " + guest.ContactNumber); 
                    }
                }
                else
                {
                    throw new GuestException("Guest Not found with ID " + relationship);
                }
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Update Guest
        public static void UpdateGuest()
        {
            Guest guest = new Guest();

            try
            {
                Console.Write("Enter Guest ID : ");
                guest.GuestID = Convert.ToInt32(Console.ReadLine());
                Console.Write("Enter Guest Name : ");
                guest.GuestName = Console.ReadLine();
                Console.Write("Enter Relationship :\n 1.Father \n 2.Mother \n 3.Brother \n 4.Sister \n 5.Cousin \n 6.Uncle \n 7.Aunt \n 8.Son \n 9.Daughter \n 10.Friend \n");
                guest.Relationship = (Relation)Enum.Parse(typeof(Relation), Console.ReadLine());
                Console.Write("Enter Contact Number : ");
                guest.ContactNumber = Console.ReadLine();

                bool guestUpdated = GuestBL.UpdateGuest(guest);

                if (guestUpdated)
                {
                    Console.WriteLine("Guest Details Updated Successfully");
                }
                else
                {
                    throw new GuestException("Guest Details not Updated");
                }
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Delete guest data
        public static void DeleteGuest()
        {
            int guestID;

            try
            {
                Console.Write("Enter Guest ID for the Guest which to be Deleted : ");
                guestID = Convert.ToInt32(Console.ReadLine());

                bool guestDeleted = GuestBL.DeleteGuest(guestID);

                if (guestDeleted)
                {
                    Console.WriteLine("Guest Details deleted Successfully");
                }
                else
                {
                    throw new GuestException("Guest details cannot be deleted");
                }
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Serialization
        public static void SerializeGuest()
        {
            try
            {
                bool guestSerialized = GuestBL.SerializeGuest();

                if (guestSerialized)
                {
                    Console.WriteLine("Guest Data Serialized Successfully");
                }
                else
                {
                    throw new GuestException("Guest Data is not Serialized");
                }
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        //Deserialization
        public static void DeserializeGuest()
        {
            try
            {
                List<Guest> guestList = GuestBL.DeserializeGuest();

                if (guestList.Count > 0)
                {
                    Console.WriteLine("Guest data Deserialized Successfully");
                    Console.WriteLine("****************************************************************");
                    Console.WriteLine("Guest ID     Guest Name      Relationship     Contact Number");
                    Console.WriteLine("****************************************************************");
                    foreach (Guest guest in guestList)
                    {
                        Console.WriteLine(guest.GuestID + "\t" + guest.GuestName + "\t" + guest.Relationship + "\t" + guest.ContactNumber);
                    }
                    Console.WriteLine("********************************************************************************************");
                }
                else
                {
                    throw new GuestException("Guest Data is not Deserialized");
                }
            }
            catch (GuestException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }

        public static void PrintMenu()
        {
            Console.WriteLine("*************Guest Phone Book************");
            Console.WriteLine("1. Add Guest");
            Console.WriteLine("2. Display All Guest");
            Console.WriteLine("3. Search Guest By ID");
            Console.WriteLine("4. Search Guest By Relationship");
            Console.WriteLine("5. Update Guest");
            Console.WriteLine("6. Delete Guest");
            Console.WriteLine("7. Serialize Employee");
            Console.WriteLine("8. Deserialize Employee");
            Console.WriteLine("9. Exit");
            Console.WriteLine("******************************************");
        }

        static void Main(string[] args)
        {
            int choice = 0;

            try
            {
                do
                {
                    PrintMenu();
                    Console.Write("Enter Your Choice : ");
                    choice = Convert.ToInt32(Console.ReadLine());

                    switch (choice)
                    {
                        case 1: AddGuest();
                            break;
                        case 2: DisplayAllGuest();
                            break;
                        case 3: DisplayAllGuestByID();
                            break;
                        case 4: DisplayAllGuestByRelation();
                            break;
                        case 5: UpdateGuest();
                            break;
                        case 6: DeleteGuest();
                            break;
                        case 7: SerializeGuest();
                            break;
                        case 8: DeserializeGuest();
                            break;
                        case 9: Environment.Exit(0);
                            break;
                        default: Console.WriteLine("Invalid Choice");
                            break;
                    }
                } while (choice != 9);
            }
            catch (SystemException ex)
            {
                Console.WriteLine(ex.Message);
            }
        }
    }
}
