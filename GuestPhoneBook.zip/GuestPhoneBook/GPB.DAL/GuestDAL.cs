﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using GPB.Entity;
using GPB.Exception;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace GPB.DAL
{
    public class GuestDAL
    {
        static List<Guest> guestList = new List<Guest>();

        //Method for adding new guest list
        public static bool AddGuest(Guest newGuest)
        {
            bool guestAdded = false;

            try
            {
                //Adding guest in list
                guestList.Add(newGuest);
                guestAdded = true;
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestAdded;
        }

        //Method for displaying all guest
        public static List<Guest> DisplayAllGuest()
        {
            return guestList;
        }

        //Method for searching guest from list using ID
        public static Guest DisplayAllGuestByID(int guestID)
        {
            Guest guest = null;

            try
            {
                //Searching guest ID
                guest = guestList.Find(g => g.GuestID == guestID);
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guest;
        }

        //Method for searching guest from list using relationship
        public static List<Guest> DisplayAllGuestByRelation(Relation relationship)
        {
            List<Guest> gstList = new List<Guest>();

            try
            {
                //Searching guest relationship
                for (int i = 0; i < guestList.Count; i++)
                {
                    if (guestList[i].Relationship == relationship)
                    {
                        gstList.Add(guestList[i]);
                    }
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return gstList;
        }

        //Method for updating guest details in guest list
        public static bool UpdateGuest(Guest guest)
        {
            bool guestUpdated = false;

            try
            {
                for (int i = 0; i < guestList.Count; i++)
                {
                    //Finding the guest using guest id
                    if (guestList[i].GuestID == guest.GuestID)
                    {
                        //updating guest details
                        guestList[i].GuestName = guest.GuestName;
                        guestList[i].Relationship = guest.Relationship;
                        guestList[i].ContactNumber = guest.ContactNumber;
                        guestUpdated = true;
                    }
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestUpdated;
        }

        //Method for deleting the guest details from guest list
        public static bool DeleteGuest(int guestID)
        {
            bool guestDeleted = false;

            try
            {
                //Search guest from the list
                Guest guest = guestList.Find(g => g.GuestID == guestID);

                //Delete the guest from the list
                if (guest != null)
                {
                    guestList.Remove(guest);
                    guestDeleted = true;
                }
                else
                {
                    throw new GuestException("Guest not found for Deletion");
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestDeleted;
        }

        public static bool SerializeGuest()
        {
            bool guestSerialized = false;

            try
            {
                if (guestList.Count > 0)
                {
                    FileStream fs = new FileStream("Guest.txt", FileMode.Create, FileAccess.Write);
                    BinaryFormatter bin = new BinaryFormatter();
                    bin.Serialize(fs, guestList);
                    fs.Close();
                    guestSerialized = true;
                }
                else
                {
                    throw new GuestException("No Guest Data, so cannot serialize");
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestSerialized;
        }

        public static List<Guest> DeserializeGuest()
        {
            List<Guest> desGuestList = null;

            try
            {
                FileStream fs = new FileStream("Guest.txt", FileMode.Open, FileAccess.Read);
                BinaryFormatter bin = new BinaryFormatter();
                desGuestList = (List<Guest>)bin.Deserialize(fs);
                fs.Close();
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desGuestList;
        }

    }
}
