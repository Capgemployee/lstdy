﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPB.Exception
{
    /// <summary>
    /// 
    /// </summary>
    
    public class GuestException:ApplicationException
    {
         //Default Constructor
        public GuestException()
            : base()
        { }

        //Parameterized Constructor
        public GuestException(string message)
            : base(message)
        { }

        public GuestException(string message,SystemException innerException)
            : base(message,innerException)
        { }
    }
}
