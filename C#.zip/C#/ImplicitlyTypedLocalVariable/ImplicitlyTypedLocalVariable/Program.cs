﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ImplicitlyTypedLocalVariable
{
    class Program
    {
        static void Main(string[] args)
        {
            var num = 5;

            Console.WriteLine(num);
            //RESTRICTIONS
            //num = "Capgemini";       Error: Cannot implicitly convert string to int

            //var val;                 Error:ImplicitlyTypedLocalVariable must be initialized

            //var val = null;          Error:Cannot assign null value while declaration

            //var val = { 1, 2, 3 };   Error: Cannot assign with array initializer

            var val = "Capgemini";
            //val = null;
            Console.WriteLine(val);

            Console.ReadKey();
        }
    }
}
