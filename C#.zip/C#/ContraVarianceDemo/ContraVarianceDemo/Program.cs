﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ContraVarianceDemo
{
    public class EmployeeComparer : IComparer<Employee>
    {
        int IComparer<Employee>.Compare(Employee x, Employee y)
        {
            if (x.DepartID > y.DepartID)
                return 1;
            else if (x.DepartID == y.DepartID)
                return 0;

            return -1;
        }
    }
    class Program
    {
        static void Main(string[] args)
        {

            EmployeeComparer empComparer = new EmployeeComparer();
            List<Employee> empList = new List<Employee>();
            empList.Add(new Employee(101,"Shruti",20));
            empList.Add(new Employee(102,"Mani",50));
            empList.Add(new Employee(103,"Aayu",10));

            empList.Sort(empComparer);

            Console.WriteLine("Sorted List of Employee Are : ");
                empList.ForEach(e=> Console.WriteLine("Employee ID : " + e.EmpID +  "Depart ID : " + e.DepartID+"  Employee Name : " + e.EmpName ));

                List<Manager> mgrList = new List<Manager>();

            mgrList.Add(new Manager(201, "Shruti", 30, 20000));
            mgrList.Add(new Manager(206, "Shruti", 90, 90000));
            mgrList.Add(new Manager(208, "Shruti", 10, 4000));

            mgrList.Sort(empComparer);

            
             Console.WriteLine("\n\nSorted List of Manager Are : ");
            mgrList.ForEach(m => Console.WriteLine("Employee ID : " + m.EmpID +  " Depart ID : " + m.DepartID+ "  Employee Name : " + m.EmpName + "  Allowance : " +m.Allowance));


                Console.ReadKey();
        }

       
     }
}
