﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FileDetails
{
    class Program
    {
        static void Main(string[] args)
        {
            Dictionary<string, string> dic = new Dictionary<string, string>();
            dic.Add("CG10101", "Raj");
            dic.Add("CG10102", "Mohit");
            dic.Add("CG10103", "Utkarsha");
            dic.Add("CG10104", "Bhushan");
            dic.Add("CG10203", "Prashant");

            Console.WriteLine("\n------------------File Details------------------------\n");

            foreach (var ele in dic.Keys)
            {
                Console.WriteLine("Keys :" + ele + "\tvalues :" + dic[ele].ToString());
            }


            dic["CG10207"] = "Manish";
            dic["CG10206"] = "Ujwal";
            dic["CG10203"] = "Manish";

            Console.WriteLine("\n------------------File Details after Adding Duplicate Values------------------------\n");

            foreach (var ele in dic.Keys)
            {
                Console.WriteLine("Keys :" + ele + "\tvalues :" + dic[ele].ToString());
            }

            Console.WriteLine("Updated Record :" + dic["CG10203"]);

            Console.WriteLine("\n------------------File Details after Updation------------------------\n");

            foreach (var ele in dic.Keys)
            {
                Console.WriteLine("Keys :" + ele + "\tvalues :" + dic[ele].ToString());
            }


            if (dic.ContainsKey("CG101557"))
            {
                dic["CG101557"] = "Nikhil";
            }
            else
            {
                dic.Add("CG101557", "Nikhil");
            }

            dic.ContainsKey("MF345762547");

            dic.Remove("CG10203");
            Console.WriteLine("\n------------------File Details after Deletion------------------------\n");

            foreach (var ele in dic.Keys)
            {
                Console.WriteLine("Keys :" + ele + "\tvalues :" + dic[ele].ToString());
            }
            Console.ReadKey();
        }
    }
}
