﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Lab5_1
{
    abstract class BankAccount:IBankAccount
    {
        protected double balance;

       

        public void Deposit(double amount)
        {
            balance = balance + amount;
        }

        public abstract double GetBalance();
        
        public abstract bool Withdraw(double amount);
        public abstract bool Transfer(IBankAccount toAccount, double amount);
        public abstract ClassLibrary.BankAccount.BankAccountTypeEnum AccountType { get; set; }
    }
}
