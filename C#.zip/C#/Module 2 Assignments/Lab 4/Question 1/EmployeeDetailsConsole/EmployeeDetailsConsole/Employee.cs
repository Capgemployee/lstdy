﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetailsConsole
{
    public abstract class Employee
    {
        int EmpID;
        string EmpName;
        string Address;
        string City;
        string Dept;
       public double Salary;

        public void EmployeeID()
        {
            Console.WriteLine("Enter Emlpoyee ID\n");
            EmpID = Convert.ToInt32(Console.ReadLine());
        }

        public void EmployeeName()
        {
            Console.WriteLine("Enter Emlpoyee Name\n");
            EmpName = Console.ReadLine();
        }

        public void EmpAddress()
        {
            Console.WriteLine("Enter Emlpoyee Address\n");
            Address = Console.ReadLine();
        }

        public void EmpCity()
        {
            Console.WriteLine("Enter Emlpoyee City\n");
            City = Console.ReadLine();
        }

        public void EmpDept()
        {
            Console.WriteLine("Enter Emlpoyee Department\n");
            Dept = Console.ReadLine();
        }

        public virtual void GetSalary()
        {
            Console.WriteLine("Enter Emlpoyee Salary\n");
            Salary = Convert.ToInt32(Console.ReadLine());
            
        }

    }
}
