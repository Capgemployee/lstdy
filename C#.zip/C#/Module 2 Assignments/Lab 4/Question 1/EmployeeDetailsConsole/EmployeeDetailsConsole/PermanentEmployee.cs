﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetailsConsole
{
    class PermanentEmployee : Employee
    {
        //double ProvidentFund;
        int NofLeaves;
        public double ProvidentFund = 1200;
        public double EmpProvidentFund
        {
            get { return ProvidentFund; }
            set { ProvidentFund = value; }
        }

        public int EmpLeaves
        {
            get { return NofLeaves; }
            set { NofLeaves = value; }
        }

        public override void GetSalary()
        {
         
            Console.WriteLine("Enter Emlpoyee Salary\n");
            Salary = Convert.ToInt32(Console.ReadLine());
            Salary = Salary - ProvidentFund;
            Console.WriteLine("Salary:" + Salary);
        }


    }
}
