﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupplierDetails
{
    class Program
    {

        static void Main(string[] args)
        {
            Console.WriteLine("\n----------------------Supplier Deatils----------------------------");
            SupplierTest obj = new SupplierTest();
           
            obj.AcceptDetails();
            Console.WriteLine("\n----------------------Supplier Deatils----------------------------");
            obj.DisplayDetails();
           
            Console.ReadKey();
        }
    }
}
