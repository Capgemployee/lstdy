﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupplierDetails
{
    public class SupplierTest
    {
      
         int supplierID;
        string  supplierName;
         string city;
         int phoneNo;
         string email;


       public void AcceptDetails()
        {
            Console.WriteLine("\nEnter Supplier ID: ");
            supplierID = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\nEnter Supplier Name: ");
            supplierName = Console.ReadLine();
            Console.WriteLine("\nEnter City: ");
            city = Console.ReadLine();
            Console.WriteLine("\nEnter Phone No: ");
            phoneNo = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("\nEnter Email ID: ");
            email = Console.ReadLine();
        }

       public void DisplayDetails()
       {
     
           Console.WriteLine("Supplier ID: " + supplierID);
           Console.WriteLine("Supplier Name: " + supplierName);

           Console.WriteLine("City: " + city);
           Console.WriteLine("Phone No: " +phoneNo);
           Console.WriteLine("Email ID: " + email);
       }

    }
}
