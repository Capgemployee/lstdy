﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CorporateProjectLibrary;

namespace CorporateProject
{
    class Program
    {
        static void Main(string[] args)
        {
            new Participant();
            Participant p = new Participant(01, "Mahesh", "Capgemini", 56, 70, 75);
            
            double tm=p.TotalObtainedMarks();
            double perc = p.PercentCalculate();
            p.PercentDisp();
            Console.ReadKey();

        }
    }
}
