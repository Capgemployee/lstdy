﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace ContactBinaryFormatter
{
    [Serializable]
    public class Contact
    {
        public long ContactNo { get; set; }
        public String ContactName { get; set; }
        public string CellNo { get; set; }
    }
    class Program
    {
        static void Main(string[] args)
        {

            Console.WriteLine("\n------------------Serialization of Contact Class Using Binary Formatter---------------------\n");
            Console.WriteLine("Enter Contact No: ");
            long no = Convert.ToInt64(Console.ReadLine());
            Console.WriteLine("\nEnter Name: ");
            string name = Console.ReadLine();
            Console.WriteLine("\nEnter Cell No ");
            string cellno = Console.ReadLine();

            Contact obj = new Contact() { ContactNo = no, ContactName = name, CellNo = cellno };
            FileStream fs = new FileStream("contactSerialize.txt", FileMode.Create, FileAccess.Write);
            BinaryFormatter bf = new BinaryFormatter();
            bf.Serialize(fs, obj);
            fs.Close();



            FileStream fs1 = new FileStream("contactSerialize.txt", FileMode.Open, FileAccess.Read);
            BinaryFormatter bf1 = new BinaryFormatter();
            Contact anotherEmp = (Contact)bf1.Deserialize(fs1);
            fs1.Close();

            Console.WriteLine("\nContact no :" + anotherEmp.ContactNo);
            Console.WriteLine("\nContact Name :" + anotherEmp.ContactName);
            Console.WriteLine("\nCell No :" + anotherEmp.CellNo);
            Console.ReadKey();
        }
    }
}