﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetails2
{
    public class Employee
    {
        int EmpID;
        string EmpName;
        string Address;
        string City;
        string Dept;
        double Sal;
        public int EmployeeID
        {
          
            set { EmpID = value; }
        }

        public string EmployeeName
        {
            get { return EmpName; }
            set { EmpName = value; }
        }

        public string EmpAddress
        {
           
            set { Address = value; }
        }

        public string Empcity
        {
            
            set { City = value; }
        }

        public string Department
        {
            
            set { Dept = value; }
        }

        public double Salary
        {
            get { return Sal; }
            set { Sal = value; }
        }
    }
}
