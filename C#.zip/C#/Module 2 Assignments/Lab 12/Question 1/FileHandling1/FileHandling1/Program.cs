﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace FileHandling1
{
    public class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter the Name of the file");
                string filepath = Console.ReadLine();

                FileInfo file = new FileInfo(filepath);
                if (!file.Exists)
                {
                    throw new FileNotFoundException("File not found");
                }

                FileStream fs1 = new FileStream(filepath, FileMode.Open, FileAccess.Read);



                StreamReader br = new StreamReader(fs1);


                Console.WriteLine(br.ReadToEnd());
                fs1.Close();
            }
            catch (FileNotFoundException ex)
            {
                Console.WriteLine(ex);
            }


           
        }
    }
}
