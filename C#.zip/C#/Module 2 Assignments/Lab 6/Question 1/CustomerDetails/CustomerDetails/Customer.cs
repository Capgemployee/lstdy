﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CustomerDetails
{
   public class Customer
    {
         public int CustomerId { get; set; }
        public string CustomerName { get; set; }
        public string Address { get; set; }
        public string City { get; set; }
        public long Phone { get; set; }
        public double CreditLimit { get; set; }

        public Customer()
        {
        }
        public Customer(int CustomerId, string CustomerName, string Address, string City, long Phone, double CreditLimit)
        {
            this.CustomerId = CustomerId;
            this.CustomerName = CustomerName;
            this.Address = Address;
            this.City = City;
            this.Phone = Phone;
            this.CreditLimit = CreditLimit;
        }
    
    }
}
