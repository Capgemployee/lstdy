﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductDetails
{
   class Program
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter Product ID :");
                int id = Convert.ToInt32(Console.ReadLine());
                if (id <= 0)
                    throw new DataEntryException("Enter valid product id");
                Console.WriteLine("Enter Product Name :");
                string name = Console.ReadLine();
                if (name == "")
                    throw new DataEntryException("Enter a valid name ");
                Console.WriteLine("Enter Product Price :");
                double price = Convert.ToDouble(Console.ReadLine());
                if (price <= 0)
                {
                    throw new DataEntryException("Price cannot be negative or 0 ");
                }
            }
            catch (DataEntryException e)
            {
                Console.WriteLine(e.Message);
            }
        }
    }
}

