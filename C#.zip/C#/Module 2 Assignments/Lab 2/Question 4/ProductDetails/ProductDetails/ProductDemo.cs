﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductDetails
{
    class ProductDemo
    {
        static void Main(string[] args)
        {
            Console.WriteLine("Enter the id of  products :");
            int prodId = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter the name of products :");
            string name = Console.ReadLine();
            Console.WriteLine("Enter price :");
            double price = Convert.ToDouble(Console.ReadLine());
            Console.WriteLine("Enter quantity :");
            int quantity = Convert.ToInt32(Console.ReadLine());


            Object obj1 = prodId; //Boxing
            Object obj2 = name;
            Object obj3 = price;
            Object obj4 = quantity;

            int prodIdU = (int)obj1;  //Unboxing
            string nameU = (string)obj2;
            double priceU = (double)obj3;
            int quantityU = (int)obj4;


            Console.WriteLine("Product ID : " + prodIdU);
            Console.WriteLine("Product Name : " + nameU);
            Console.WriteLine("Price : " + priceU);
            Console.WriteLine("Quantity : " + quantityU);
            Console.WriteLine("Amt Payable : " + (priceU * quantityU));

            Console.ReadKey();
        }
    }
}
