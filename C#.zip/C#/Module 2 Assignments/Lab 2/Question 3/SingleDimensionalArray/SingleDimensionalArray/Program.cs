﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SingleDimensionalArray
{
    class Program
    {
        static void Main(string[] args)
        {

            string[] city = new string[5];

            Console.WriteLine("Enter Names of the city:\n");
            for (int i = 0; i < 5; i++)
            {
                city[i] = Console.ReadLine();
            }

            Console.WriteLine("-----------------------Names of the city--------------------");
            foreach(string name in city)
            {
                Console.WriteLine(name + "\n");

            }
        }
    }
}
