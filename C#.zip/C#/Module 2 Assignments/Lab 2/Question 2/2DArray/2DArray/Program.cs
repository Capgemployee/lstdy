﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _2DArray
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] TwoDArray = new int[5, 6];

            for (int i = 0; i < TwoDArray.GetLength(0); i++)
            {
               
                for (int j = 0; j < TwoDArray.GetLength(1); j++)
                {
                    Console.WriteLine("Enter Data " + j + ":");
                    TwoDArray[i, j] = Convert.ToInt32(Console.ReadLine());
                }
            }
            Console.WriteLine("\n -------------------Data Entered by user in the Array---------------------");
            for (int i = 0; i < TwoDArray.GetLength(0); i++)
            {
                for (int j = 0; j < TwoDArray.GetLength(1); j++)
                {
                    Console.Write(TwoDArray[i, j] + "\t");
                }
            }
            Console.ReadKey();
        }

    }
}