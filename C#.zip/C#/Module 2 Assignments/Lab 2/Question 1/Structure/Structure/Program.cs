﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Structure
{
    struct NumberDemo
    {
        public int Number;

        public void Squareno()
        {
            Console.WriteLine("Sqaure of"+Number+" :"  + Number * Number);
        }

        public void Cubeno()
        {
            Console.WriteLine("Cube of"+Number + " :" + Number * Number * Number);
        }
    };
    class Program
    {
        static void Main(string[] args)
        {
            NumberDemo X;
            int ch;
            X.Number = 2;
            Console.WriteLine("\n\n--------------------------PROGRAM FOR STRUCTURE-------------------------------\n");
            do
            {
                Console.WriteLine("\n1:Press 1 for Square\n2:Press 2 for Cube\n3:Exit\n");
                Console.WriteLine("\nEnter Your Choice:");
                ch = Convert.ToInt32(Console.ReadLine());
                switch (ch)
                {
                    case 1:
                        X.Squareno();
                        break;
                    case 2:
                        X.Cubeno();
                        break;  
                    default: break;
                }

            } while (ch != 3);
        }
    }
}


