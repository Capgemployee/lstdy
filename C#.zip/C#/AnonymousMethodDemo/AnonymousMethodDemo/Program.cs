﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AnonymousMethodDemo
{
    public delegate void AnonymousDelegate();

    class Program
    {

        public static void Display()
        {
            Console.WriteLine("Display Method is called");
        }
        static void Main(string[] args)
        {
            //AnonymousDelegate del = new AnonymousDelegate(Display);
            //del.Invoke();

            AnonymousDelegate del = delegate
            {
                Console.WriteLine("Annonymous Method is called");
            };
            del();  //invoking del
            Console.ReadKey();
        }
    }
}
