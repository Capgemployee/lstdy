﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExtensionMethod
{

    public static class StringExtension   //make the class static
    {
        public static string RemoveNonNumeric(this string s)
        {
            StringBuilder sb = new StringBuilder();
            for (int i = 0; i < s.Length; i++)
            {
                if (char.IsDigit(s[i]))
                    sb.Append(s[i]);
            }
            return sb.ToString();

        }
    }
    class Program
    {
        
        static void Main(string[] args)
        {
            string phone = "123-123-1234";
            string newPhone=phone.RemoveNonNumeric();
            Console.WriteLine(newPhone);

            Console.ReadKey();

        }
    }
}
