﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaExpressionWithReturnType
{
    public delegate int AddDelegate(int num1,int num2);
    class Program
    {
        static void Main(string[] args)
        {
            AddDelegate del = delegate(int num1, int num2)
            {
                return num1 + num2;
            };
            Console.WriteLine("Result using annonymous method= " + del(2, 4));

            AddDelegate lambda = (num1, num2) => { return num1 + num2; };
                                                     //coz it is two statement so it should have braces
            Console.WriteLine("Result using lambda method= " + lambda(2, 4));
            Console.ReadKey();
        }
    }
}
