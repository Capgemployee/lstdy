﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConstructorInInheritence
{
    public class Manager: Employee
    {
        public Manager():base()
        {
            Console.WriteLine("This is default constructor of manager");
        }
        public Manager(string name): base(name)
        {
            Console.WriteLine("This is parameterized constructor manager");
        }
    }
}
