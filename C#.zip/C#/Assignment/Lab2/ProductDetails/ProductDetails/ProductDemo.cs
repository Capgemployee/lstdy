﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProductDetails
{
    class ProductDemo
    {
        static void Main(string[] args)
        {
            int productId, price, quantity;
            string productName;
            Console.Write("Enter the id of product: ");
            productId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the name of product: ");
            productName = (Console.ReadLine());
            Console.Write("Enter the price of product: ");
            price = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the quantity of product: ");
            quantity = Convert.ToInt32(Console.ReadLine());

            //performing boxing
            Object obj = productId;
            Object obj1 = productName;
            Object obj2 = price;
            Object obj3 = quantity;

            //performing unboxing
            int prodId = (int)obj;
            string prodName = (string)obj1;
            int prodPrice = (int)obj2;
            int prodQuantity = (int)obj3;

            //displaying the details

            Console.WriteLine("Product Details: ");
            Console.WriteLine("Product ID: " + prodId);
            Console.WriteLine("Product Name: " + prodName);
            Console.WriteLine("Price: " + prodPrice);
            Console.WriteLine("Quantity: " + prodQuantity);

            int amountPayable = prodPrice * prodQuantity;
            Console.WriteLine("Amount Payable: " + amountPayable);

            Console.ReadKey();
        }
    }
}
