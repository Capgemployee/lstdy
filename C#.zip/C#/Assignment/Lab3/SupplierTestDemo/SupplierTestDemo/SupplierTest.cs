﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SupplierTestDemo
{
    class SupplierTest
    {
        static void Main(string[] args)
        {
            Supplier s = new Supplier();
            s.AcceptDetails();
            s.DisplayDetails();
            Console.ReadKey();
        }
    }
}
