﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ProjectLibrary
{
    public class Participant
    {
        private int empID;
        private string name;
        static string companyName;
        private int foundationMarks;
        private int webBasicMarks;
        private int dotNetMarks;
        
        public int EmployeeID
        {
            get{return empID;}
            set { empID = value; }
        }
        public string Name
        {
            get { return name; }
            set { name = value; }
        }
        
        public int FoundationMarks
        {
            get { return foundationMarks; }
            set 
            {
                if (value > 0 && value<100)
                    foundationMarks = value;
                else
                    foundationMarks = 0;     
            }
        }
        public int WebBasicMarks
        {
            get { return webBasicMarks; }
            set 
            {
                if (value > 0 && value<100)
                    webBasicMarks = value;
                else
                    webBasicMarks = 0;     
            }
        }
        public int DotNetMarks
        {
            get { return dotNetMarks; }
            set
            {
                if (value > 0 && value < 100)
                    dotNetMarks = value;
                else
                    dotNetMarks = 0;
            }
        }
        public Participant()
        {
        }

        public Participant(int empId,string empName,int fdMarks,int wbMarks,int dtMarks)
        {
            this.empID = empId;
            this.name = empName;
            this.foundationMarks = fdMarks;
            this.webBasicMarks = wbMarks;
            this.dotNetMarks = dtMarks;
           
        }
        static Participant()
        {
            companyName = "Corporate Unniversity";
            Console.WriteLine("Company Name : " + companyName);
        }

        public int ObtainedMarks(int fdMarks, int wbMarks, int dtMarks)
        {
            return fdMarks + wbMarks + dtMarks;
        }
     
        public double Percentage(int totalmarks,int obtMarks)
        {
            double res = (obtMarks * 100 / totalmarks);
            return res;
        }

        public void DisplayPercentage(double percent)
        {
            Console.WriteLine("Percentage = " + percent);
        }
    
    }
}
