﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace StudentRecord
{
    class Program
    {
        public static void Main(string[] args)
        {
            Student std = new Student();

            std.RollNumber = 11;
            std.StudenName = "Shruti";
            std.Age = 8;
            std.Gender = 'F';
            std.DOB = new DateTime(2010, 1, 18);
            std.Address = "Mumbai";
            std.Percentage = 80.25f;

            Console.WriteLine("Student Details Are:");
            Console.WriteLine();
            Console.WriteLine(" Roll-No= " + std.RollNumber);
            Console.WriteLine(" Name= " + std.StudenName);
            Console.WriteLine(" Age= " + std.Age);
            Console.WriteLine(" Gender= " + std.Gender);
            Console.WriteLine(" DOB= " + std.DOB);
            Console.WriteLine(" Address= " + std.Address);
            Console.WriteLine(" Percentage= " + std.Percentage);

            Console.ReadKey();

        }
    }
}
