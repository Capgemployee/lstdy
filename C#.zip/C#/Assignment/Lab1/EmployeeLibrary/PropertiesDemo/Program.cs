﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            Employee[] emp = new Employee[2];
            for (int i = 0; i < emp.Length; i++)
            {
                emp[i] = new Employee();
                Console.WriteLine("Enter Employee Id: ");
                emp[i].EmpId = Convert.ToInt32(Console.ReadLine());

                Console.WriteLine("Enter Employee Name: ");
                emp[i].EmpName = (Console.ReadLine());

                Console.WriteLine("Enter Employee Address: ");
                emp[i].EmpAddress = (Console.ReadLine());

                Console.WriteLine("Enter Employee Department: ");
                emp[i].EmpDepartment = (Console.ReadLine());

                Console.WriteLine("Enter City: ");
                emp[i].City = (Console.ReadLine());

                Console.WriteLine("Enter Employee Salary: ");
                emp[i].EmpSalary = Convert.ToDouble(Console.ReadLine());

            }
            for (int i = 0; i < emp.Length; i++)
            {
                Console.WriteLine("\n\nEmployee Id is : " + emp[i].EmpId);
                Console.WriteLine("\n\nEmployee Name is : " + emp[i].EmpName);
                Console.WriteLine("\n\nEmployee Address is : " + emp[i].EmpAddress);
                Console.WriteLine("\n\nEmployee Department is : " + emp[i].EmpDepartment);
                Console.WriteLine("\n\nCity Name is : " + emp[i].City);
                Console.WriteLine("\n\nEmployee Salary is : " + emp[i].EmpSalary);
            }
            Console.ReadKey();

        }
    }
}
