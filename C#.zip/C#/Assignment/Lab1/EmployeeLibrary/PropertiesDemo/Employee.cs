﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PropertiesDemo
{
    public class Employee
    {
        int empid;
        string empname;
        string empaddress;
        string department;
        string city;
        double sal;

        public int EmpId
        {
            get { return empid; }
            set { empid = value; }
        }
        public string EmpName
        {
            get { return empname; }
            set { empname = value; }
        }
        public string EmpAddress
        {
            get { return empaddress; }
            set { empaddress = value; }
        }
        public string EmpDepartment
        {
            get { return department; }
            set { department = value; }
        }
        public string City
        {
            get { return city; }
            set { city = value; }
        }
        public double EmpSalary
        {
            get { return sal; }
            set { sal = value; }
        }
    }
}
