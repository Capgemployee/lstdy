﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeLibrary
{
    public class Employee
    {
        int empid;
        string empname;
        string empaddress;
        string department;
        string city;
        double sal;

        public void setEmpId(int emp_id)
        {
            empid = emp_id;
        }
        public void setEmpName(string emp_name)
        {
            empname = emp_name;
        }
        public void setEmpAddress(string emp_address)
        {
            empaddress = emp_address;
        }
        public void setEmpDept(string emp_dept)
        {
            department = emp_dept;
        }
        public void setCity(string city_name)
        {
            city = city_name;
        }
        public void setEmpSalary(double emp_sal)
        {
            sal = emp_sal;
        }
        public double getSalary()
        {
            return sal;
        }
        public string getName()
        {
            return empname;
        }
    }
}
