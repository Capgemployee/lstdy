﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetails
{
    class Program
    {
        public abstract class Employee{
            public abstract double GetSalary(double salary,double ex_sal);
        }

        public class ContractEMployee :Employee
        {
            double perks
            {
                get{return perks;}
                set{perks=value;}
            }
             
            public override double GetSalary(double salary, double perk)
            {
                return salary=salary+perk;
            }
        }

        public class PermanentEmployee: Employee
        {
            int noOfLeaves
            {
                get{return noOfLeaves;}
                set{noOfLeaves=value;}
            }






        static void Main(string[] args)
        {
        }
    }
}
