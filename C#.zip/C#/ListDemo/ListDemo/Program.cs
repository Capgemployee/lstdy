﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ListDemo
{
    class Program
    {
        public class Employee
        {
            public int EmployeeID;
            public string EmployeeName;
            public double Salary;
        }
        static void Main(string[] args)
        {
            List<string> cityList=new List<string>();
            cityList.Add("Pune");
            cityList.Add("Mumbai");
            cityList.Add("Goa");
            cityList.Add("Delhi");
            cityList.Add("Hyderabad");

            Console.WriteLine("City List: ");
            foreach (string item in cityList)
            {
                Console.WriteLine(item);
            }
            List<Employee> empList = new List<Employee>();
            empList.Add(new Employee() {EmployeeID=101, EmployeeName="Shruti", Salary=2000});
            empList.Add(new Employee() {EmployeeID=101, EmployeeName="Shruti", Salary=2000});
            empList.Add(new Employee() {EmployeeID=101, EmployeeName="Shruti", Salary=2000});
            empList.Add(new Employee() { EmployeeID = 101, EmployeeName = "Shruti", Salary = 2000 });

            Console.WriteLine("\nEmployee list is :");
            foreach (Employee emp in empList)
            {
                Console.WriteLine("Employee ID : " + emp.EmployeeID + "Employee Name : " + emp.EmployeeName + "Salary : "
                    + emp.Salary);
            }

            Console.ReadKey();
        }
    }
}
