﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPB.Entity
{
    /// <summary>
    /// 
    /// </summary>
    [Serializable]
    public class Guest
    {
        public int GuestID { get; set; }

        public string GuestName { get; set; }

        public Relation Relationship { get; set; }

        public string ContactNumber { get; set; }

        public Guest()
        { }

        //public override string ToString()
        //{
        //    return string.Format("{0}, {1}, {2}, {3}", GuestID, GuestName, Relationship, ContactNumber);
        //}
    }
}
