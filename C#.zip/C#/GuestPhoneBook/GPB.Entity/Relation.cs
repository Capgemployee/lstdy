﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GPB.Entity
{
    public enum Relation
    {
        Father=1,
        Mother=2,
        Brother=3,
        Sister=4,
        Cousin=5,
        Uncle=6,
        Aunt=7,
        Son=8,
        Daughter=9,
        Friend=10
    }
}
