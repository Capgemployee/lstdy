﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using GPB.Entity;
using GPB.Exception;
using GPB.DAL;

namespace GPB.BL
{
    public class GuestBL
    {

        public static bool ValidateGuest(Guest guest)
        {
            bool guestValidated = true;
            StringBuilder message = new StringBuilder();

            try
            {
                //Validating Guest ID
                if (guest.GuestID < 100000 || guest.GuestID > 999999)
                {
                    message.Append("Guest ID should have 6 digits only\n");
                    guestValidated = false;
                }

                //Validating Guest Name
                if (guest.GuestName == String.Empty)
                {
                    message.Append("Guest Name should be Provided\n");
                    guestValidated = false;
                }
                else if (!Regex.IsMatch(guest.GuestName, "[A-Z][a-z]+"))
                {
                    message.Append("Guest Name should have alphabets only and it should start with capital\n");
                    guestValidated = false;
                }

                //Validating Guest Contact Number
                if (guest.ContactNumber == String.Empty)
                {
                    message.Append("Phone Number should be Provided\n");
                    guestValidated = false;
                }
                else if (!Regex.IsMatch(guest.ContactNumber, "[7-9][0-9]{9}"))
                {
                    message.Append("Phone Number should have 10 digits exactly and it should start with 7 or 8 or 9\n");
                    guestValidated = false;
                }

                if (guestValidated == false)
                {
                    throw new GuestException(message.ToString());
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestValidated;
        }

        //Add method
        public static bool AddGuest(Guest newGuest)
        {
            bool guestAdded = false;

            try
            {
                if (ValidateGuest(newGuest))
                {
                    guestAdded = GuestDAL.AddGuest(newGuest);
                }
                else
                {
                    throw new GuestException("Employee Details are invalid");
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestAdded;
        }

        //list all data
        public static List<Guest> DisplayAllGuest()
        {
            List<Guest> guestList = null;

            try
            {
                guestList = GuestDAL.DisplayAllGuest();
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestList;
        }

        //search guest list by id
        public static Guest DisplayAllGuestByID(int guestID)
        {
            Guest guest = null;

            try
            {
                guest = GuestDAL.DisplayAllGuestByID(guestID);
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guest;
        }

        //search guest list by relationship
        public static List<Guest> DisplayAllGuestByRelation(Relation relationship)
        {
            List<Guest> guestList = null;

            try
            {
                guestList = GuestDAL.DisplayAllGuestByRelation(relationship);
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestList;
        }

        //Update guest
        public static bool UpdateGuest(Guest guest)
        {
            bool guestUpdated = false;

            try
            {
                if (ValidateGuest(guest))
                {
                    guestUpdated = GuestDAL.UpdateGuest(guest);
                }
                else
                {
                    throw new GuestException("Guest details are invalid for updation");
                }
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestUpdated;
        }

        //Delete Guest
        public static bool DeleteGuest(int guestID)
        {
            bool guestDeleted = false;

            try
            {
                guestDeleted = GuestDAL.DeleteGuest(guestID);
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestDeleted;
        }

        //Serialization
        public static bool SerializeGuest()
        {
            bool guestSerialized = false;

            try
            {
                guestSerialized = GuestDAL.SerializeGuest();
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return guestSerialized;
        }

        //Desrialization
        public static List<Guest> DeserializeGuest()
        {
            List<Guest> desGuestList = null;

            try
            {
                desGuestList = GuestDAL.DeserializeGuest();
            }
            catch (GuestException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return desGuestList;
        }








    }
}
