﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LambdaExpression
{
    public delegate void LambdaDelegate();

    class Program
    {
        static void Main(string[] args)
        {
            //annonymous block
            LambdaDelegate annonymous = delegate
            {
                Console.WriteLine("Annonymous Method Called!");
            };
            annonymous();

            //lambda Expression
            LambdaDelegate lambda = () => Console.WriteLine("Lambda Expression called!");
            lambda();
            Console.ReadKey();

        }
    }
}
