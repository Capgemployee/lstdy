﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ExplicitInterfaceDemo
{
    public class Employee:IMyInterface, IMyInterface2   //used explicit implementation
    {

        void IMyInterface.Show()   //methods are not public 
        {
            Console.WriteLine("IMyInterface 1 show method implemented in employee class");
        }

        void IMyInterface.Display()
        {
            Console.WriteLine("IMyInterface 1 display method implemented in employee class");
        }

        void IMyInterface2.Show()
        {
            Console.WriteLine("IMyInterface 2  show method implemented in employee class");
        }

        void IMyInterface2.Print()
        {
            Console.WriteLine("IMyInterface 2 print method implemented in employee class");
        }
    }
}
