﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DataTypeDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            int num = 10;

            //boxing : Converting value type to reference type
            object o = num;
            //unboxing : Converting reference type to value type
            int number = (int)o;

            //Nullable Types
            //Nullable<int> val = null;
            int? val = null;

            if (val.HasValue)
            {
                Console.WriteLine("Value is : " + val.Value);
            }
            else
            {
                Console.WriteLine("Value is null");
            }

            Console.Write("Press any key to continue---");
            Console.ReadKey();
        }
    }
}
