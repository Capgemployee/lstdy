﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;

namespace ArrayListDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            ArrayList arrList = new ArrayList();

            arrList.Add(10);
            arrList.Add(".NET");
            arrList.Add(true);
            arrList.Add(DateTime.Now);
            arrList.Add('c');
            arrList.Add(23.4);
            arrList.Add(35465.54435);
            arrList.Add("Learning");
            arrList.Add(false);

            Console.WriteLine("Number of Elements : " + arrList.Count);
            Console.WriteLine("Capacity of ArrayList : " + arrList.Capacity);

            Console.WriteLine("Array List Elements : ");
            foreach (var ele in arrList)
            {
                Console.Write(ele + "  ");
            }

            object[] arr = new object[20];

            //CopyTo(Array) - Copy all collection element in array and pasted from position 0
            //arrList.CopyTo(arr);

            //CopyTo(Array, arrayIndex) - Copy all collection element in array and pasted from position 5 
            //arrList.CopyTo(arr, 5);

            //CopyTo(listindex, Array, arrayIndex, numberofElements) - Copies the number of elements from the particular index of collection and pasted in the array to particular position 
            arrList.CopyTo(2, arr, 6, 5);
            Console.WriteLine("\n\n\nArray elements which are copied from array list : ");
            for (int i = 0; i < arr.Length; i++)
            {
                if (arr[i] == null)
                    Console.Write("NULL" + "  ");
                else
                    Console.Write(arr[i] + "  ");
            }
            Console.WriteLine("Array End");

            Console.ReadKey();
        }
    }
}
