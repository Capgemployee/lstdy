﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MathLibraryToolDemo;

namespace MathLibraryTest
{
    public class MathTestClass
    {
        MathClass objMath = new MathClass();








        public void TestSubstractNumber()
        {
            int result=0;
            result=objMath.SubNumbers(7,3);
            Assert.
    }
}
