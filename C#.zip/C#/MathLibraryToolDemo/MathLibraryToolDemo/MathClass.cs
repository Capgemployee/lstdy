﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MathLibraryToolDemo
{
    public class MathClass
    {

        public int AddNumbers(int firstNumber, int secondNumber)
        {
            return firstNumber + secondNumber;
        }

        public int SubNumbers(int firstNumber, int secondNumber)
        {
            return firstNumber - secondNumber;
        }

        public int MulNumbers(int firstNumber, int secondNumber)
        {
            return firstNumber * secondNumber;
        }

        public int DivNumbers(int firstNumber, int secondNumber)
        {
            int result = 0;
            try
            {

                result = firstNumber / secondNumber;
            }
            catch (DivideByZeroException)
            {
                throw;
            }
            return result;
        }

    }
}
