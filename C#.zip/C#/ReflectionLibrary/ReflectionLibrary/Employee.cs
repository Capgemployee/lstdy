﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ReflectionLibrary
{
    public class Employee
    {
        int empID;
        string empName;
        int sal;

        public int EmployeeID
        {
            get { return empID; }
            set { empID = value; }
        }

        public string EmployeeName
        {
            get { return empName; }
            set { empName = value; }
        }

        public int Salary
        {
            get { return sal; }
            set { sal = value; }
        }
    }

}
