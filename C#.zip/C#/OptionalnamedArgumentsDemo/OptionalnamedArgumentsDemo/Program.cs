﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace OptionalnamedArgumentsDemo
{
    class Program
    {

        public static void Addition(int num1=1, int num2=2, int num3=3)
        {
            Console.WriteLine("{0}+{1}+{2}=>{3}", num1, num2, num3, (num1 + num2 + num3));
        }
        static void Main(string[] args)
        {
            Console.WriteLine("\n\n  **Output of positional argument** ");
            Program p = new Program();
            Program.Addition();
            Program.Addition(100);
            Program.Addition(100, 200);
            Program.Addition(100, 200, 300);
        //  Program.Addition(100, ,300); Error : Argument missing

            //Named argument

            Console.WriteLine("\n\n  **Output of named argument** ");

            Program.Addition(num1: 2, num2: 5, num3: 8);
            Program.Addition(2, num2: 4, num3: 9);
            Program.Addition(2, 5, num3: 6);
        //  Program.Addition(num1: 10, 20, num3: 40); Error:Named argument should always be aftr positional argument
        //  Program.Addition(2, 5, num2: 5); Error: positinal argument already assigned to num2

            Console.ReadKey();
            
        }
    }
}
