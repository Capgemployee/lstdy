﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace AttributeDemo
{
    [AttributeUsage(AttributeTargets.Class,AllowMultiple=true)]
    public class AuthorAttribute: Attribute
    {
        string name;
        string dom;

        public AuthorAttribute(string name, string dom)
        {
            this.name = name;
            this.dom = dom;

        }

        public String Name { get { return name; } }

        public String DOM { get { return dom; } }

    }
}
