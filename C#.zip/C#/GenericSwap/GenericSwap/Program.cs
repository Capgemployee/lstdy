﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GenericSwap
{
    class Program
    {
        public void Swap<T>(ref T val1, ref T val2 )
        {
            T temp = val1;
            val1 = val2;
            val2 = temp;
        }
        static void Main(string[] args)
        {
            int num1 = 20, num2 = 10;

            Program p = new Program();
            p.Swap<int>(ref num1, ref num2);

            Console.WriteLine(num1);
            Console.WriteLine(num2);
            Console.ReadKey();
        }
    }
}
